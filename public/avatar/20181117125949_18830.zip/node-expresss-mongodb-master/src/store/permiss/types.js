export const SET_FILTER_ROUTES = 'SET_FILTER_ROUTES'
export const RM_ROUTES = 'RM_ROUTES'
export const SET_ROUTES = 'SET_ROUTES'
