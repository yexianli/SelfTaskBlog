export const USER_INFO = 'USER_INFO' // 用户角色信息
export const RESET_ROLE = 'RESET_ROLE' // 重置用户角色
