// import Main from '@/views/Main'
/*
* 非侧边栏的路由可以放在此处
*/
// export default [
//   {
//     path: '/order',
//     component: Main,
//     icon: 'dashboard',
//     children: [
//       {
//         path: 'order/:id',
//         name: 'order_index',
//         meta: {
//           title: 'orderDetail'
//         },
//         component: () => import('@/views/router-page/order.vue')
//       }
//     ]
//   }
// ]
